- First install xampp or any local server.
- Second create database called webtech
- Import this sql file
- Run browser
- write, localhost/GashChat

Then start group chatting!